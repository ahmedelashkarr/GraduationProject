// ============================================================
//  SmartNavUIBuilder.cs  —  Editor-only scene builder
//  Menu: Tools → Smart Indoor Nav → Build Full UI
//
//  Drops into Assets/Editor/  (never ships in a build)
//  Requires: TextMeshPro package installed.
//  After running, assign sprites via the SpriteAssigner component
//  on each screen root, then hit "Apply Sprites" in its Inspector.
// ============================================================
#if UNITY_EDITOR
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEditor;
using System.Collections.Generic;

public static class SmartNavUIBuilder
{
    // ── Colours ───────────────────────────────────────────────────────────────
    static Color C(string hex) {
        ColorUtility.TryParseHtmlString(hex, out Color c); return c;
    }
    static readonly Color COL_PRIMARY      = C("#1565C0");
    static readonly Color COL_PRIMARY_DARK = C("#0D47A1");
    static readonly Color COL_WHITE        = C("#FFFFFF");
    static readonly Color COL_BG_GREY      = C("#F5F5F5");
    static readonly Color COL_TEXT_PRI     = C("#212121");
    static readonly Color COL_TEXT_SEC     = C("#757575");
    static readonly Color COL_DIVIDER      = C("#E0E0E0");
    static readonly Color COL_STOP_RED     = C("#E53935");
    static readonly Color COL_ICON_COMP    = C("#1E88E5");
    static readonly Color COL_ICON_ROOM    = C("#FB8C00");
    static readonly Color COL_ICON_CAF     = C("#00897B");
    static readonly Color COL_ICON_EXIT    = C("#43A047");
    static readonly Color COL_TRANSPARENT  = new Color(0,0,0,0);

    // ── Entry point ───────────────────────────────────────────────────────────
    [MenuItem("Tools/Smart Indoor Nav/Build Full UI")]
    static void BuildAll()
    {
        // ── Root manager object ──
        GameObject mgr = GetOrCreate("UIManager");
        EnsureComponent<UIManager>(mgr);
        EnsureComponent<NavigationManager>(mgr);

        // ── Canvas ──
        GameObject canvasGO = GetOrCreate("Canvas");
        Canvas canvas = EnsureComponent<Canvas>(canvasGO);
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 0;

        CanvasScaler scaler = EnsureComponent<CanvasScaler>(canvasGO);
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(390, 844);
        scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight = 0.5f;

        EnsureComponent<GraphicRaycaster>(canvasGO);

        // ── Event system ──
        if (GameObject.FindObjectOfType<UnityEngine.EventSystems.EventSystem>() == null)
        {
            GameObject es = new GameObject("EventSystem");
            es.AddComponent<UnityEngine.EventSystems.EventSystem>();
            es.AddComponent<UnityEngine.EventSystems.StandaloneInputModule>();
        }

        // ── Screens ──
        GameObject splash = BuildSplashScreen(canvasGO.transform);
        GameObject main   = BuildMainScreen(canvasGO.transform);
        GameObject arNav  = BuildARNavScreen(canvasGO.transform);

        // Wire UIManager references
        UIManager uiMgr = mgr.GetComponent<UIManager>();
        uiMgr.splashScreen       = splash;
        uiMgr.mainScreen         = main;
        uiMgr.arNavigationScreen = arNav;

        // Start with splash active
        splash.SetActive(true);
        main.SetActive(false);
        arNav.SetActive(false);

        Debug.Log("[SmartNavUI] ✅  Canvas built successfully. Assign sprites in the Inspector.");
        Selection.activeGameObject = canvasGO;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  SPLASH SCREEN
    // ═══════════════════════════════════════════════════════════════════════
    static GameObject BuildSplashScreen(Transform parent)
    {
        // Root panel — full screen blue gradient background
        GameObject root = Panel("SplashScreen", parent,
            AnchorPreset.StretchAll, Vector2.zero, Vector2.zero);
        Image bg = root.GetComponent<Image>();
        bg.color = COL_PRIMARY;
        root.AddComponent<SplashScreenController>();

        // ── Logo container ──
        GameObject logo = Empty("LogoContainer", root.transform);
        RT(logo).anchorMin = new Vector2(0.3f, 0.58f);
        RT(logo).anchorMax = new Vector2(0.7f, 0.78f);
        RT(logo).offsetMin = RT(logo).offsetMax = Vector2.zero;

        // Pin background (white teardrop — placeholder Image, sprite assigned externally)
        GameObject pin = ImageGO("ARPinImage", logo.transform, COL_WHITE);
        RT(pin).anchorMin = Vector2.zero; RT(pin).anchorMax = Vector2.one;
        RT(pin).offsetMin = RT(pin).offsetMax = Vector2.zero;
        pin.AddComponent<SpriteSlot>().slotKey = "ar_pin_icon";

        // AR badge text on top of pin
        GameObject arTxt = TMPLabel("ARBadgeText", logo.transform, "AR", 28, FontStyle.Bold, COL_WHITE);
        RT(arTxt).anchorMin = new Vector2(0.2f, 0.35f);
        RT(arTxt).anchorMax = new Vector2(0.8f, 0.65f);
        RT(arTxt).offsetMin = RT(arTxt).offsetMax = Vector2.zero;
        arTxt.GetComponent<TextMeshProUGUI>().alignment = TextAlignmentOptions.Center;

        // ── App title ──
        GameObject title = TMPLabel("AppTitleText", root.transform,
            "Smart Indoor Navigation", 22, FontStyle.Normal, COL_WHITE);
        RT(title).anchorMin = new Vector2(0.05f, 0.50f);
        RT(title).anchorMax = new Vector2(0.95f, 0.56f);
        RT(title).offsetMin = RT(title).offsetMax = Vector2.zero;
        title.GetComponent<TextMeshProUGUI>().alignment = TextAlignmentOptions.Center;
        title.GetComponent<TextMeshProUGUI>().fontStyle = FontStyles.Bold;

        // ── Page dots ──
        GameObject dotsGrp = HorizontalGroup("PageDotGroup", root.transform, 8);
        RT(dotsGrp).anchorMin = new Vector2(0.35f, 0.46f);
        RT(dotsGrp).anchorMax = new Vector2(0.65f, 0.49f);
        RT(dotsGrp).offsetMin = RT(dotsGrp).offsetMax = Vector2.zero;
        for (int i = 0; i < 3; i++)
        {
            GameObject dot = ImageGO($"Dot{i+1}", dotsGrp.transform,
                i == 0 ? COL_WHITE : new Color(1,1,1,0.4f));
            LayoutElement le = dot.AddComponent<LayoutElement>();
            le.preferredWidth = 8; le.preferredHeight = 8;
            dot.GetComponent<Image>().sprite = CreateCircleSprite();
        }

        // ── Destinations card (bottom sheet) ──
        GameObject card = Panel("PopularDestinationsPanel", root.transform,
            AnchorPreset.StretchBottom, new Vector2(0, 0), new Vector2(0, 310));
        Image cardImg = card.GetComponent<Image>();
        cardImg.color = COL_WHITE;

        // Add VerticalLayoutGroup to card
        VerticalLayoutGroup vlg = card.AddComponent<VerticalLayoutGroup>();
        vlg.padding = new RectOffset(16, 16, 20, 20);
        vlg.spacing = 0;
        vlg.childControlHeight = false;
        vlg.childControlWidth  = true;
        vlg.childForceExpandHeight = false;

        // Section header
        GameObject sec = TMPLabel("SectionTitleText", card.transform,
            "Popular Destinations", 17, FontStyle.Bold, COL_TEXT_PRI);
        LE(sec, 24);

        // Spacer after header
        Spacer(card.transform, 12);

        // Destination rows
        AddDestRow(card.transform, "ComputerLabRow",  "Computer Lab", "15 meters · 30 sec", COL_ICON_COMP, "icon_computer");
        AddDestRow(card.transform, "Room305Row",      "Room 305",     "25 meters · 1 min",  COL_ICON_ROOM, "icon_room");
        AddDestRow(card.transform, "CafeteriaRow",    "Cafeteria",    "40 meters · 2 min",  COL_ICON_CAF,  "icon_cafeteria");
        AddDestRow(card.transform, "ExitRow",         "Exit",         "10 meters · 20 sec", COL_ICON_EXIT, "icon_exit");

        // Wire SplashScreenController buttons
        SplashScreenController sc = root.GetComponent<SplashScreenController>();
        sc.computerLabButton = card.transform.Find("ComputerLabRow")?.GetComponent<Button>();
        sc.room305Button     = card.transform.Find("Room305Row")?.GetComponent<Button>();
        sc.cafeteriaButton   = card.transform.Find("CafeteriaRow")?.GetComponent<Button>();
        sc.exitButton        = card.transform.Find("ExitRow")?.GetComponent<Button>();

        return root;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  MAIN SCREEN
    // ═══════════════════════════════════════════════════════════════════════
    static GameObject BuildMainScreen(Transform parent)
    {
        GameObject root = Panel("MainScreen", parent,
            AnchorPreset.StretchAll, Vector2.zero, Vector2.zero);
        root.GetComponent<Image>().color = COL_WHITE;
        root.AddComponent<MainScreenController>();

        // ── Top Search Bar ──
        GameObject topBar = Panel("TopSearchBar", root.transform,
            AnchorPreset.StretchTop, new Vector2(0, -56), Vector2.zero);
        topBar.GetComponent<Image>().color = COL_PRIMARY;
        HorizontalLayoutGroup hTop = topBar.AddComponent<HorizontalLayoutGroup>();
        hTop.padding = new RectOffset(12, 12, 8, 8);
        hTop.spacing = 8;
        hTop.childAlignment = TextAnchor.MiddleCenter;
        hTop.childControlHeight = true; hTop.childControlWidth = false;
        hTop.childForceExpandWidth = false;

        // Location pin icon
        GameObject locIcon = ImageGO("LocationIconImage", topBar.transform, COL_WHITE);
        LE(locIcon, -1, 28, 28);
        locIcon.AddComponent<SpriteSlot>().slotKey = "ar_pin_icon";

        // Search input
        GameObject searchGO = CreateSearchField("SearchInputField", topBar.transform);
        LE(searchGO, 1, -1, 38);

        // Voice button
        GameObject voiceBtn = CreateIconButton("VoiceSearchButton", topBar.transform,
            "🎤", COL_TRANSPARENT, COL_WHITE, 36, 36);

        // ── Floor Bar ──
        GameObject floorBar = Panel("FloorBar", root.transform,
            AnchorPreset.StretchTop, new Vector2(-56, -44), new Vector2(0, -56));
        floorBar.GetComponent<Image>().color = C("#FAFAFA");
        HorizontalLayoutGroup hFloor = floorBar.AddComponent<HorizontalLayoutGroup>();
        hFloor.padding = new RectOffset(12, 12, 0, 0);
        hFloor.spacing = 8;
        hFloor.childAlignment = TextAnchor.MiddleCenter;
        hFloor.childForceExpandWidth = false;
        hFloor.childControlWidth = false; hFloor.childControlHeight = true;

        // Back + Floor label
        GameObject backBtn = CreateTextButton("BackButton", floorBar.transform,
            "‹  Floor 2", COL_TEXT_PRI, COL_TRANSPARENT, 17);
        LE(backBtn, -1, 110, 44);

        Spacer(floorBar.transform, 0, true);

        // Menu + Lock icons
        GameObject menuBtn = CreateIconButton("MenuButton", floorBar.transform,
            "☰", COL_TRANSPARENT, COL_TEXT_PRI, 40, 40);
        GameObject lockBtn = CreateIconButton("LockButton", floorBar.transform,
            "🔒", COL_TRANSPARENT, COL_TEXT_PRI, 40, 40);

        // Add bottom divider line to floorBar
        GameObject div = ImageGO("FloorBarDivider", floorBar.transform, COL_DIVIDER);
        RT(div).anchorMin = new Vector2(0, 0); RT(div).anchorMax = new Vector2(1, 0);
        RT(div).offsetMin = Vector2.zero; RT(div).offsetMax = new Vector2(0, 1);

        // ── Map Container ──
        GameObject mapCont = Panel("MapContainer", root.transform,
            AnchorPreset.StretchTop, new Vector2(-100, -200), new Vector2(0, -100));
        mapCont.GetComponent<Image>().color = C("#E8EFF7");

        // Floor map raw image
        GameObject mapImg = new GameObject("FloorMapImage");
        mapImg.transform.SetParent(mapCont.transform, false);
        RawImage ri = mapImg.AddComponent<RawImage>();
        ri.color = new Color(1,1,1,0.9f);
        RT(mapImg).anchorMin = Vector2.zero; RT(mapImg).anchorMax = Vector2.one;
        RT(mapImg).offsetMin = RT(mapImg).offsetMax = Vector2.zero;

        // "You" marker overlay
        GameObject youMarker = Panel("YouMarker", mapCont.transform,
            AnchorPreset.Center, Vector2.zero, Vector2.zero);
        RT(youMarker).sizeDelta = new Vector2(60, 28);
        RT(youMarker).anchoredPosition = new Vector2(20, -20);
        youMarker.GetComponent<Image>().color = COL_PRIMARY;
        GameObject youTxt = TMPLabel("YouLabel", youMarker.transform,
            "You", 12, FontStyle.Bold, COL_WHITE);
        RT(youTxt).anchorMin = Vector2.zero; RT(youTxt).anchorMax = Vector2.one;
        RT(youTxt).offsetMin = RT(youTxt).offsetMax = Vector2.zero;
        youTxt.GetComponent<TextMeshProUGUI>().alignment = TextAlignmentOptions.Center;

        // User location dot on map
        GameObject locDot = ImageGO("UserLocationDot", mapCont.transform, COL_WHITE);
        RT(locDot).anchorMin = RT(locDot).anchorMax = new Vector2(0.5f, 0.45f);
        RT(locDot).sizeDelta = new Vector2(24, 24);
        locDot.AddComponent<SpriteSlot>().slotKey = "user_location_dot";

        // ── Popular Destinations — Top card (Computer Lab only) ──
        GameObject cardTop = Panel("PopularDestinationsCard_Top", root.transform,
            AnchorPreset.StretchTop, new Vector2(-300, -90), new Vector2(0, -200));
        cardTop.GetComponent<Image>().color = COL_WHITE;
        AddTopShadow(cardTop);
        VerticalLayoutGroup vTop = cardTop.AddComponent<VerticalLayoutGroup>();
        vTop.padding = new RectOffset(16, 16, 12, 8);
        vTop.spacing = 0;
        vTop.childControlHeight = false; vTop.childControlWidth = true;
        vTop.childForceExpandHeight = false;

        TMPLabel("SectionTitle_Top", cardTop.transform,
            "Popular Destinations", 17, FontStyle.Bold, COL_TEXT_PRI);
        LE(cardTop.transform.GetChild(0).gameObject, 24);
        Spacer(cardTop.transform, 8);
        AddDestRow(cardTop.transform, "ComputerLabRow_Top", "Computer Lab",
            "15 meters · 30 sec", COL_ICON_COMP, "icon_computer");

        // ── Popular Destinations — Main card ──
        GameObject cardMain = Panel("PopularDestinationsCard_Main", root.transform,
            AnchorPreset.StretchTop, new Vector2(-580, -170), new Vector2(0, -300));
        cardMain.GetComponent<Image>().color = COL_WHITE;
        AddTopShadow(cardMain);
        VerticalLayoutGroup vMain = cardMain.AddComponent<VerticalLayoutGroup>();
        vMain.padding = new RectOffset(16, 16, 12, 8);
        vMain.spacing = 0;
        vMain.childControlHeight = false; vMain.childControlWidth = true;
        vMain.childForceExpandHeight = false;

        TMPLabel("SectionTitle_Main", cardMain.transform,
            "Popular Destinations", 17, FontStyle.Bold, COL_TEXT_PRI);
        LE(cardMain.transform.GetChild(0).gameObject, 24);
        Spacer(cardMain.transform, 8);
        AddDestRow(cardMain.transform, "ComputerLabRow", "Computer Lab",
            "15 meters · 30 sec", COL_ICON_COMP, "icon_computer");
        AddDestRow(cardMain.transform, "CafeteriaRow",   "Cafeteria",
            "40 meters · 2 min",  COL_ICON_CAF,  "icon_cafeteria");
        AddDestRow(cardMain.transform, "ExitRow",        "Exit",
            "10 meters · 20 sec", COL_ICON_EXIT, "icon_exit");

        // ── Start AR Button ──
        GameObject startBtn = CreateTextButton("StartARButton", root.transform,
            "Start AR Navigation", COL_WHITE, COL_PRIMARY, 17);
        RT(startBtn).anchorMin = new Vector2(0, 0);
        RT(startBtn).anchorMax = new Vector2(1, 0);
        RT(startBtn).pivot = new Vector2(0.5f, 0);
        RT(startBtn).offsetMin = new Vector2(16, 24);
        RT(startBtn).offsetMax = new Vector2(-16, 76);

        // ── Wire MainScreenController ──
        MainScreenController mc = root.GetComponent<MainScreenController>();
        mc.backButton       = backBtn.GetComponent<Button>();
        mc.voiceSearchButton= voiceBtn.GetComponent<Button>();
        mc.menuButton       = menuBtn.GetComponent<Button>();
        mc.lockButton       = lockBtn.GetComponent<Button>();
        mc.startARButton    = startBtn.GetComponent<Button>();
        mc.computerLabButton= cardMain.transform.Find("ComputerLabRow")?.GetComponent<Button>();
        mc.cafeteriaButton  = cardMain.transform.Find("CafeteriaRow")?.GetComponent<Button>();
        mc.exitButton       = cardMain.transform.Find("ExitRow")?.GetComponent<Button>();

        TMP_InputField sif = searchGO.GetComponent<TMP_InputField>();
        mc.searchInputField = sif;

        return root;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  AR NAVIGATION SCREEN
    // ═══════════════════════════════════════════════════════════════════════
    static GameObject BuildARNavScreen(Transform parent)
    {
        GameObject root = Panel("ARNavigationScreen", parent,
            AnchorPreset.StretchAll, Vector2.zero, Vector2.zero);
        root.GetComponent<Image>().color = COL_TRANSPARENT; // AR camera shows through
        root.AddComponent<ARNavigationScreenController>();

        // ── Top bar ──
        GameObject topBar = Panel("ARTopBar", root.transform,
            AnchorPreset.StretchTop, new Vector2(-56, -56), Vector2.zero);
        topBar.GetComponent<Image>().color = new Color(0.1f, 0.1f, 0.12f, 0.85f);
        HorizontalLayoutGroup hTop = topBar.AddComponent<HorizontalLayoutGroup>();
        hTop.padding = new RectOffset(12, 12, 8, 8);
        hTop.spacing = 8;
        hTop.childAlignment = TextAnchor.MiddleCenter;
        hTop.childControlHeight = true; hTop.childControlWidth = false;
        hTop.childForceExpandWidth = false;

        GameObject backBtn = CreateIconButton("BackButton", topBar.transform,
            "‹", COL_TRANSPARENT, COL_WHITE, 36, 40);
        LE(backBtn, -1, 36, 40);

        GameObject searchGO = CreateSearchField("SearchInputField", topBar.transform);
        LE(searchGO, 1, -1, 38);

        GameObject voiceBtn = CreateIconButton("VoiceSearchButton", topBar.transform,
            "🎤", COL_TRANSPARENT, COL_WHITE, 36, 36);

        // ── AR camera feed placeholder ──
        GameObject arFeed = new GameObject("ARCameraFeed");
        arFeed.transform.SetParent(root.transform, false);
        RawImage rawImg = arFeed.AddComponent<RawImage>();
        rawImg.color = new Color(0.15f, 0.15f, 0.2f, 1f); // dark placeholder
        RT(arFeed).anchorMin = Vector2.zero; RT(arFeed).anchorMax = Vector2.one;
        RT(arFeed).offsetMin = RT(arFeed).offsetMax = Vector2.zero;

        // ── AR arrows overlay (floor arrows) ──
        GameObject arrowsGroup = Empty("ARArrowsOverlay", root.transform);
        RT(arrowsGroup).anchorMin = new Vector2(0.2f, 0.3f);
        RT(arrowsGroup).anchorMax = new Vector2(0.8f, 0.65f);
        RT(arrowsGroup).offsetMin = RT(arrowsGroup).offsetMax = Vector2.zero;
        // Spawn 4 stacked arrow images to simulate the floor arrows
        for (int i = 0; i < 4; i++)
        {
            GameObject arrow = ImageGO($"FloorArrow_{i+1}", arrowsGroup.transform,
                new Color(0.23f, 0.51f, 0.96f, 1f - i * 0.18f));
            RT(arrow).anchorMin = new Vector2(0, i * 0.22f);
            RT(arrow).anchorMax = new Vector2(1, i * 0.22f + 0.20f);
            RT(arrow).offsetMin = RT(arrow).offsetMax = Vector2.zero;
            arrow.AddComponent<SpriteSlot>().slotKey = "ar_floor_arrow";
        }

        // ── Bottom overlay ──
        GameObject bottomOverlay = Empty("BottomOverlay", root.transform);
        RT(bottomOverlay).anchorMin = new Vector2(0, 0);
        RT(bottomOverlay).anchorMax = new Vector2(1, 0);
        RT(bottomOverlay).pivot = new Vector2(0.5f, 0);
        RT(bottomOverlay).sizeDelta = new Vector2(0, 160);
        VerticalLayoutGroup vBot = bottomOverlay.AddComponent<VerticalLayoutGroup>();
        vBot.padding = new RectOffset(16, 16, 0, 24);
        vBot.spacing = 10;
        vBot.childControlHeight = false; vBot.childControlWidth = true;
        vBot.childForceExpandHeight = false;

        // Control buttons row
        GameObject ctrlRow = Empty("ControlButtonsRow", bottomOverlay.transform);
        LE(ctrlRow, -1, -1, 48);
        HorizontalLayoutGroup hCtrl = ctrlRow.AddComponent<HorizontalLayoutGroup>();
        hCtrl.spacing = 10;
        hCtrl.childAlignment = TextAnchor.MiddleCenter;
        hCtrl.childControlWidth = false; hCtrl.childControlHeight = true;
        hCtrl.childForceExpandWidth = true;

        GameObject stopBtn    = BuildControlPill("StopButton",    ctrlRow.transform, "⏹  Stop",    COL_STOP_RED,  "stop_button_icon");
        GameObject recenterBtn= BuildControlPill("RecenterButton",ctrlRow.transform, "↺  Recenter",COL_PRIMARY,  "");
        GameObject mapBtn     = BuildControlPill("MapButton",     ctrlRow.transform, "📍  Map",     C("#1F2937"), "ar_pin_icon");

        // Destination card
        GameObject destCard = BuildDestinationCard(bottomOverlay.transform);

        // Wire ARNavigationScreenController
        ARNavigationScreenController arc = root.GetComponent<ARNavigationScreenController>();
        arc.backButton                   = backBtn.GetComponent<Button>();
        arc.searchInputField             = searchGO.GetComponent<TMP_InputField>();
        arc.voiceSearchButton            = voiceBtn.GetComponent<Button>();
        arc.stopButton                   = stopBtn.GetComponent<Button>();
        arc.recenterButton               = recenterBtn.GetComponent<Button>();
        arc.mapButton                    = mapBtn.GetComponent<Button>();
        arc.arCameraFeed                 = rawImg;
        arc.destinationNameText          = destCard.transform.Find("LabelsGroup/DestinationNameText")
                                              ?.GetComponent<TextMeshProUGUI>();
        arc.destinationDistanceText      = destCard.transform.Find("LabelsGroup/DestinationMetaText")
                                              ?.GetComponent<TextMeshProUGUI>();
        arc.destinationCardChevronButton = destCard.GetComponent<Button>();

        return root;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  PREFAB BUILDER — DestinationRow
    // ═══════════════════════════════════════════════════════════════════════
    [MenuItem("Tools/Smart Indoor Nav/Save DestinationRow Prefab")]
    static void SaveDestRowPrefab()
    {
        string dir = "Assets/Prefabs";
        if (!System.IO.Directory.Exists(dir))
            System.IO.Directory.CreateDirectory(dir);

        // Build a standalone row to save as prefab
        GameObject row = BuildDestRowGO("DestinationRow",
            "Destination Name", "15 meters · 30 sec", COL_ICON_COMP, "icon_computer");

        string path = dir + "/DestinationRow.prefab";
        PrefabUtility.SaveAsPrefabAsset(row, path);
        GameObject.DestroyImmediate(row);
        Debug.Log("[SmartNavUI] ✅  DestinationRow prefab saved to " + path);
        AssetDatabase.Refresh();
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  SHARED HELPERS
    // ═══════════════════════════════════════════════════════════════════════

    static void AddDestRow(Transform parent, string name, string destName,
        string meta, Color iconColor, string slotKey)
    {
        GameObject row = BuildDestRowGO(name, destName, meta, iconColor, slotKey);
        row.transform.SetParent(parent, false);
    }

    static GameObject BuildDestRowGO(string name, string destName,
        string meta, Color iconColor, string slotKey)
    {
        // Root button
        GameObject row = new GameObject(name);
        Button btn = row.AddComponent<Button>();
        Image rowImg = row.AddComponent<Image>();
        rowImg.color = COL_TRANSPARENT;

        RectTransform rt = row.GetComponent<RectTransform>();
        rt.sizeDelta = new Vector2(0, 60);

        HorizontalLayoutGroup h = row.AddComponent<HorizontalLayoutGroup>();
        h.padding = new RectOffset(0, 0, 8, 8);
        h.spacing = 12;
        h.childAlignment = TextAnchor.MiddleLeft;
        h.childControlHeight = true; h.childControlWidth = false;
        h.childForceExpandWidth = false;

        // Icon background
        GameObject iconBg = ImageGO("IconBackground", row.transform, iconColor);
        LE(iconBg, -1, 44, 44);
        iconBg.GetComponent<Image>().sprite = CreateRoundedRectSprite();
        GameObject icon = ImageGO("IconImage", iconBg.transform, COL_WHITE);
        RT(icon).anchorMin = new Vector2(0.15f, 0.15f);
        RT(icon).anchorMax = new Vector2(0.85f, 0.85f);
        RT(icon).offsetMin = RT(icon).offsetMax = Vector2.zero;
        icon.AddComponent<SpriteSlot>().slotKey = slotKey;

        // Labels group
        GameObject labGrp = Empty("LabelsGroup", row.transform);
        LE(labGrp, 1, -1, 44);
        VerticalLayoutGroup vl = labGrp.AddComponent<VerticalLayoutGroup>();
        vl.childAlignment = TextAnchor.MiddleLeft;
        vl.childControlHeight = false; vl.childControlWidth = true;
        vl.childForceExpandHeight = false;
        vl.spacing = 2;

        GameObject nameT = TMPLabel("DestinationNameText", labGrp.transform,
            destName, 16, FontStyle.Bold, COL_TEXT_PRI);
        LE(nameT, -1, -1, 20);

        GameObject metaT = TMPLabel("DestinationMetaText", labGrp.transform,
            meta, 13, FontStyle.Normal, COL_TEXT_SEC);
        LE(metaT, -1, -1, 17);

        // Chevron
        GameObject chev = TMPLabel("ChevronImage", row.transform, "›", 20,
            FontStyle.Normal, C("#BDBDBD"));
        LE(chev, -1, 24, 44);
        chev.GetComponent<TextMeshProUGUI>().alignment = TextAlignmentOptions.Center;

        // Bottom divider
        GameObject divider = ImageGO("RowDivider", row.transform, COL_DIVIDER);
        // Can't do absolute positioning in HLG easily — add as overlay child
        // Will be set via RT in post
        LE(divider, -1, 0, 1);

        // Add DestinationRow logic
        DestinationRow dr = row.AddComponent<DestinationRow>();
        dr.destinationName     = destName;
        dr.iconBackgroundColor = iconColor;

        return row;
    }

    static GameObject BuildControlPill(string name, Transform parent,
        string label, Color bgColor, string iconSlot)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        Button btn = go.AddComponent<Button>();
        Image img = go.AddComponent<Image>();
        img.color = new Color(bgColor.r, bgColor.g, bgColor.b, 0.88f);
        img.sprite = CreateRoundedRectSprite();

        HorizontalLayoutGroup h = go.AddComponent<HorizontalLayoutGroup>();
        h.padding = new RectOffset(14, 14, 0, 0);
        h.spacing = 6;
        h.childAlignment = TextAnchor.MiddleCenter;
        h.childControlHeight = true; h.childControlWidth = false;
        h.childForceExpandWidth = false;

        if (!string.IsNullOrEmpty(iconSlot))
        {
            GameObject ic = ImageGO("PillIcon", go.transform, COL_WHITE);
            LE(ic, -1, 18, 18);
            ic.AddComponent<SpriteSlot>().slotKey = iconSlot;
        }

        GameObject txt = TMPLabel("PillLabel", go.transform, label, 14,
            FontStyle.Bold, COL_WHITE);
        LE(txt, -1, 90, 20);

        return go;
    }

    static GameObject BuildDestinationCard(Transform parent)
    {
        GameObject card = new GameObject("DestinationCard");
        card.transform.SetParent(parent, false);
        Button btn = card.AddComponent<Button>();
        Image img = card.AddComponent<Image>();
        img.color = COL_WHITE;
        img.sprite = CreateRoundedRectSprite();
        LE(card, -1, -1, 80);
        AddTopShadow(card);

        HorizontalLayoutGroup h = card.AddComponent<HorizontalLayoutGroup>();
        h.padding = new RectOffset(16, 16, 0, 0);
        h.spacing = 14;
        h.childAlignment = TextAnchor.MiddleLeft;
        h.childControlHeight = true; h.childControlWidth = false;
        h.childForceExpandWidth = false;

        // Direction arrow icon
        GameObject arrow = ImageGO("DirectionArrowImage", card.transform, COL_PRIMARY);
        LE(arrow, -1, 48, 48);
        arrow.GetComponent<Image>().sprite = CreateRoundedRectSprite();
        arrow.AddComponent<SpriteSlot>().slotKey = "ar_floor_arrow";

        // Labels
        GameObject labGrp = Empty("LabelsGroup", card.transform);
        LE(labGrp, 1, -1, 56);
        VerticalLayoutGroup vl = labGrp.AddComponent<VerticalLayoutGroup>();
        vl.childAlignment = TextAnchor.MiddleLeft;
        vl.childControlHeight = false; vl.childControlWidth = true;
        vl.childForceExpandHeight = false; vl.spacing = 3;

        GameObject nameT = TMPLabel("DestinationNameText", labGrp.transform,
            "Computer Lab", 20, FontStyle.Bold, COL_TEXT_PRI);
        LE(nameT, -1, -1, 24);

        GameObject metaT = TMPLabel("DestinationMetaText", labGrp.transform,
            "15 meters · 30 sec", 14, FontStyle.Normal, COL_TEXT_SEC);
        LE(metaT, -1, -1, 18);

        // Chevron
        GameObject chev = TMPLabel("ChevronIcon", card.transform, "›",
            22, FontStyle.Normal, C("#BDBDBD"));
        LE(chev, -1, 24, 44);
        chev.GetComponent<TextMeshProUGUI>().alignment = TextAlignmentOptions.Center;

        return card;
    }

    // ─── Primitive factories ──────────────────────────────────────────────────

    static GameObject Panel(string name, Transform parent,
        AnchorPreset preset, Vector2 offsetMin, Vector2 offsetMax)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.AddComponent<Image>().color = COL_WHITE;
        ApplyAnchor(go.GetComponent<RectTransform>(), preset, offsetMin, offsetMax);
        return go;
    }

    static GameObject Empty(string name, Transform parent)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.AddComponent<RectTransform>();
        return go;
    }

    static GameObject ImageGO(string name, Transform parent, Color color)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.AddComponent<Image>().color = color;
        return go;
    }

    static GameObject TMPLabel(string name, Transform parent, string text,
        float size, FontStyle style, Color color)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        TextMeshProUGUI tmp = go.AddComponent<TextMeshProUGUI>();
        tmp.text = text;
        tmp.fontSize = size;
        tmp.color = color;
        tmp.fontStyle = style == FontStyle.Bold ? FontStyles.Bold : FontStyles.Normal;
        tmp.raycastTarget = false;
        return go;
    }

    static GameObject CreateSearchField(string name, Transform parent)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);

        Image bg = go.AddComponent<Image>();
        bg.color = new Color(1,1,1,0.15f);
        bg.sprite = CreateRoundedRectSprite();

        TMP_InputField field = go.AddComponent<TMP_InputField>();

        // Placeholder child
        GameObject placeholder = TMPLabel("Placeholder", go.transform,
            "Search for room, lab, office…", 14, FontStyle.Normal,
            new Color(1,1,1,0.55f));
        RT(placeholder).anchorMin = Vector2.zero;
        RT(placeholder).anchorMax = Vector2.one;
        RT(placeholder).offsetMin = new Vector2(10, 0);
        RT(placeholder).offsetMax = new Vector2(-10, 0);

        // Text child
        GameObject textChild = TMPLabel("Text", go.transform,
            "", 14, FontStyle.Normal, COL_WHITE);
        RT(textChild).anchorMin = Vector2.zero;
        RT(textChild).anchorMax = Vector2.one;
        RT(textChild).offsetMin = new Vector2(10, 0);
        RT(textChild).offsetMax = new Vector2(-10, 0);

        field.placeholder   = placeholder.GetComponent<TextMeshProUGUI>();
        field.textComponent = textChild.GetComponent<TextMeshProUGUI>();

        return go;
    }

    static GameObject CreateTextButton(string name, Transform parent,
        string label, Color textColor, Color bgColor, float fontSize)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        Image img = go.AddComponent<Image>();
        img.color = bgColor;
        if (bgColor != COL_TRANSPARENT) img.sprite = CreateRoundedRectSprite();
        Button btn = go.AddComponent<Button>();

        GameObject txt = TMPLabel("Label", go.transform, label,
            fontSize, FontStyle.Bold, textColor);
        RT(txt).anchorMin = Vector2.zero;
        RT(txt).anchorMax = Vector2.one;
        RT(txt).offsetMin = RT(txt).offsetMax = Vector2.zero;
        txt.GetComponent<TextMeshProUGUI>().alignment = TextAlignmentOptions.Center;

        return go;
    }

    static GameObject CreateIconButton(string name, Transform parent,
        string icon, Color bgColor, Color iconColor, float w, float h)
    {
        GameObject go = CreateTextButton(name, parent, icon, iconColor, bgColor, 18);
        LE(go, -1, w, h);
        go.GetComponentInChildren<TextMeshProUGUI>().alignment = TextAlignmentOptions.Center;
        return go;
    }

    static GameObject HorizontalGroup(string name, Transform parent, float spacing)
    {
        GameObject go = Empty(name, parent);
        HorizontalLayoutGroup h = go.AddComponent<HorizontalLayoutGroup>();
        h.spacing = spacing;
        h.childAlignment = TextAnchor.MiddleCenter;
        h.childControlHeight = true; h.childControlWidth = false;
        h.childForceExpandWidth = false;
        return go;
    }

    static void Spacer(Transform parent, float height, bool flexible = false)
    {
        GameObject sp = Empty("Spacer", parent);
        LayoutElement le = sp.AddComponent<LayoutElement>();
        if (flexible) le.flexibleWidth = 1;
        else          le.preferredHeight = height;
    }

    // ── LayoutElement shorthand ──
    static void LE(GameObject go, float flexW = -1,
        float prefW = -1, float prefH = -1)
    {
        LayoutElement le = go.GetComponent<LayoutElement>() ?? go.AddComponent<LayoutElement>();
        if (flexW  >= 0) le.flexibleWidth  = flexW;
        if (prefW  >= 0) le.preferredWidth  = prefW;
        if (prefH  >= 0) le.preferredHeight = prefH;
    }

    static RectTransform RT(GameObject go) => go.GetComponent<RectTransform>();

    static void AddTopShadow(GameObject go)
    {
        // Unity UI doesn't have built-in shadows; use Outline as stand-in
        Outline o = go.AddComponent<Outline>();
        o.effectColor = new Color(0,0,0,0.08f);
        o.effectDistance = new Vector2(0, -2);
    }

    // ── Anchor helpers ────────────────────────────────────────────────────────

    enum AnchorPreset { StretchAll, StretchTop, StretchBottom, Center }

    static void ApplyAnchor(RectTransform rt, AnchorPreset preset,
        Vector2 offsetMin, Vector2 offsetMax)
    {
        switch (preset)
        {
            case AnchorPreset.StretchAll:
                rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
                rt.offsetMin = offsetMin;    rt.offsetMax = offsetMax;
                break;
            case AnchorPreset.StretchTop:
                rt.anchorMin = new Vector2(0, 1); rt.anchorMax = Vector2.one;
                rt.pivot     = new Vector2(0.5f, 1);
                rt.offsetMin = offsetMin;          rt.offsetMax = offsetMax;
                break;
            case AnchorPreset.StretchBottom:
                rt.anchorMin = Vector2.zero; rt.anchorMax = new Vector2(1, 0);
                rt.pivot     = new Vector2(0.5f, 0);
                rt.offsetMin = offsetMin;    rt.offsetMax = offsetMax;
                break;
            case AnchorPreset.Center:
                rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
                rt.pivot = new Vector2(0.5f, 0.5f);
                rt.sizeDelta = Vector2.zero;
                break;
        }
    }

    // ── Sprite helpers ────────────────────────────────────────────────────────
    static Sprite CreateCircleSprite()    => CreateProceduralSprite(64, true);
    static Sprite CreateRoundedRectSprite() => CreateProceduralSprite(64, false);

    static Sprite CreateProceduralSprite(int size, bool circle)
    {
        Texture2D tex = new Texture2D(size, size);
        tex.filterMode = FilterMode.Bilinear;
        Color[] pixels = new Color[size * size];
        float half = size / 2f;
        float r = half - 1;
        for (int y = 0; y < size; y++)
        for (int x = 0; x < size; x++)
        {
            float dx = x - half + 0.5f, dy = y - half + 0.5f;
            bool inside = circle
                ? (dx*dx + dy*dy) <= r*r
                : (Mathf.Abs(dx) <= half - 6 || Mathf.Abs(dy) <= half - 6) &&
                  (dx*dx + dy*dy) <= half * half * 1.8f;
            pixels[y * size + x] = inside ? Color.white : Color.clear;
        }
        tex.SetPixels(pixels);
        tex.Apply();
        return Sprite.Create(tex,
            new Rect(0, 0, size, size),
            new Vector2(0.5f, 0.5f),
            100, 0, SpriteMeshType.FullRect,
            new Vector4(size/4f, size/4f, size/4f, size/4f));
    }

    static GameObject GetOrCreate(string name)
    {
        return GameObject.Find(name) ?? new GameObject(name);
    }

    static T EnsureComponent<T>(GameObject go) where T : Component
        => go.GetComponent<T>() ?? go.AddComponent<T>();
}
#endif
