using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// MainScreenController
/// Attach to the "MainScreen" Panel GameObject.
/// </summary>
public class MainScreenController : MonoBehaviour
{
    [Header("Top Bar")]
    public Button backButton;
    public TMP_InputField searchInputField;
    public Button voiceSearchButton;
    public TextMeshProUGUI floorLabel;          // "Floor 2"
    public Button menuButton;
    public Button lockButton;

    [Header("Map")]
    public RawImage floorMapImage;              // assign floor-plan RenderTexture or Texture2D

    [Header("Destination List — Popular")]
    public Button computerLabButton;
    public Button cafeteriaButton;
    public Button exitButton;

    [Header("CTA")]
    public Button startARButton;

    void Start()
    {
        backButton?.onClick.AddListener(OnBackClicked);
        voiceSearchButton?.onClick.AddListener(OnVoiceSearchClicked);
        menuButton?.onClick.AddListener(OnMenuClicked);
        lockButton?.onClick.AddListener(OnLockClicked);

        computerLabButton?.onClick.AddListener(OnComputerLabClicked);
        cafeteriaButton?.onClick.AddListener(OnCafeteriaClicked);
        exitButton?.onClick.AddListener(OnExitClicked);

        startARButton?.onClick.AddListener(OnStartARClicked);

        if (searchInputField != null)
            searchInputField.onEndEdit.AddListener(OnSearchSubmitted);

        RefreshDestinationHighlight();
    }

    void OnEnable() => RefreshDestinationHighlight();

    void RefreshDestinationHighlight()
    {
        // highlight the currently selected destination row if needed
        string dest = NavigationManager.Instance?.CurrentDestination ?? "";
        Debug.Log($"[Main] Active destination: {dest}");
    }

    // ── Top bar ───────────────────────────────────────────────────────────────

    public void OnBackClicked()
    {
        Debug.Log("[Main] Back tapped");
        UIManager.Instance?.ShowSplashScreen();
    }

    public void OnVoiceSearchClicked()
    {
        Debug.Log("[Main] Voice search tapped — start mic input here");
    }

    public void OnMenuClicked()
    {
        Debug.Log("[Main] Hamburger menu tapped");
    }

    public void OnLockClicked()
    {
        Debug.Log("[Main] Lock/settings tapped");
    }

    public void OnSearchSubmitted(string query)
    {
        Debug.Log($"[Main] Search submitted: {query}");
        NavigationManager.Instance?.SetDestination(query);
        RefreshDestinationHighlight();
    }

    // ── Destination rows ──────────────────────────────────────────────────────

    public void OnComputerLabClicked()
    {
        Debug.Log("[Main] Computer Lab selected");
        NavigationManager.Instance?.SetDestination("Computer Lab");
        RefreshDestinationHighlight();
    }

    public void OnCafeteriaClicked()
    {
        Debug.Log("[Main] Cafeteria selected");
        NavigationManager.Instance?.SetDestination("Cafeteria");
        RefreshDestinationHighlight();
    }

    public void OnExitClicked()
    {
        Debug.Log("[Main] Exit selected");
        NavigationManager.Instance?.SetDestination("Exit");
        RefreshDestinationHighlight();
    }

    // ── CTA ───────────────────────────────────────────────────────────────────

    public void OnStartARClicked()
    {
        Debug.Log("[Main] Start AR Navigation tapped");
        UIManager.Instance?.ShowARNavigationScreen();
    }
}
