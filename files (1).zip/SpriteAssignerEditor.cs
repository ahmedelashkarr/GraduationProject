#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(SpriteAssigner))]
public class SpriteAssignerEditor : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();

        EditorGUILayout.Space(8);

        SpriteAssigner sa = (SpriteAssigner)target;

        if (GUILayout.Button("▶  Apply Sprites to All Slots", GUILayout.Height(36)))
        {
            sa.ApplySprites();
            EditorUtility.SetDirty(sa.gameObject);
        }

        EditorGUILayout.HelpBox(
            "Steps:\n" +
            "1. Import your SVG/PNG files into Assets/Sprites/\n" +
            "2. Drag each sprite into the matching Binding entry above.\n" +
            "3. Click 'Apply Sprites to All Slots'.",
            MessageType.Info);
    }
}
#endif
