# Smart Indoor Navigation — Complete Unity UI Package
## Version 2 (with SVG Assets + Editor Builder)

---

## 📦 Package Contents

```
UnityUI_Complete/
├── Editor/
│   ├── SmartNavUIBuilder.cs       ← ONE-CLICK scene builder (menu item)
│   └── SpriteAssignerEditor.cs    ← Custom Inspector for sprite wiring
├── Scripts/
│   ├── UIManager.cs               ← Screen switcher singleton
│   ├── NavigationManager.cs       ← Destination / distance state
│   ├── SplashScreenController.cs  ← Splash button handlers
│   ├── MainScreenController.cs    ← Main screen button handlers
│   ├── ARNavigationScreenController.cs
│   ├── DestinationRow.cs          ← Reusable row prefab script
│   ├── SpriteSlot.cs              ← Marker for auto sprite assignment
│   ├── SpriteAssigner.cs          ← Bulk sprite applicator
│   ├── ARArrowAnimator.cs         ← Pulsing AR floor arrows
│   ├── ScreenTransitionAnimator.cs← Fade in/out transitions
│   └── NavTypography.cs           ← Font size / colour constants
└── Sprites/SVG/
    ├── ar_pin_icon.svg
    ├── ar_floor_arrow.svg
    ├── icon_computer.svg
    ├── icon_cafeteria.svg
    ├── icon_room.svg
    ├── stop_button_icon.svg
    ├── success_check.svg
    └── user_location_dot.svg
```

---

## 🚀 Quick Start (5 steps)

### Step 1 — Import Package
Copy the three folders (`Editor/`, `Scripts/`, `Sprites/`) into your
`Assets/` directory.

### Step 2 — Import SVG Sprites
1. Move all `.svg` files from `Sprites/SVG/` into `Assets/Sprites/`.
2. In Unity's **Project** window, select each `.svg` file.
3. In the **Inspector**, set **Texture Type** → `Sprite (2D and UI)`,
   then click **Apply**.
   *(Unity 2021.2+ supports SVG import natively via the Vector Graphics
   package; for older versions, export as 512×512 PNG first.)*

### Step 3 — Install TextMeshPro
`Window → TextMeshPro → Import TMP Essential Resources`
(one-time, skippable if already done).

### Step 4 — Build the Canvas
`Tools → Smart Indoor Nav → Build Full UI`

This creates the entire Canvas hierarchy in your open scene in one click.

### Step 5 — Assign Sprites
1. Select the **Canvas** GameObject in the Hierarchy.
2. Add the **SpriteAssigner** component (or find it already there).
3. Drag each sprite from `Assets/Sprites/` into the matching binding slot.
4. Click **▶ Apply Sprites to All Slots**.

Done — all icons appear in every screen.

---

## 🗂 Full Canvas Hierarchy

```
Canvas  [CanvasScaler: 390×844, Match 0.5]
│
├─ SplashScreen  [SplashScreenController, ScreenTransitionAnimator]
│   ├─ LogoContainer
│   │   ├─ ARPinImage              Image  ← ar_pin_icon sprite
│   │   └─ ARBadgeText             TMP  "AR"  28px Bold  White
│   ├─ AppTitleText                TMP  "Smart Indoor Navigation"  22px Bold  White
│   ├─ PageDotGroup                HorizontalLayoutGroup
│   │   ├─ Dot1                    Image  circle  White
│   │   ├─ Dot2                    Image  circle  White 40%
│   │   └─ Dot3                    Image  circle  White 40%
│   └─ PopularDestinationsPanel    Panel  White  bottom-anchored h=310
│       ├─ SectionTitleText        TMP  "Popular Destinations"  17px Bold  #212121
│       ├─ ComputerLabRow          Button [DestinationRow]
│       ├─ Room305Row              Button [DestinationRow]
│       ├─ CafeteriaRow            Button [DestinationRow]
│       └─ ExitRow                 Button [DestinationRow]
│
├─ MainScreen  [MainScreenController, ScreenTransitionAnimator]
│   ├─ TopSearchBar                Panel  #1565C0  top-anchored h=56
│   │   ├─ LocationIconImage       Image  ← ar_pin_icon  28×28  White
│   │   ├─ SearchInputField        TMP_InputField  rounded
│   │   └─ VoiceSearchButton       Button  "🎤"  White
│   ├─ FloorBar                    Panel  #FAFAFA  top-anchored h=44
│   │   ├─ BackButton              Button  "‹  Floor 2"
│   │   ├─ Spacer                  LayoutElement  flexW=1
│   │   ├─ MenuButton              Button  "☰"
│   │   ├─ LockButton              Button  "🔒"
│   │   └─ FloorBarDivider         Image  #E0E0E0  h=1  bottom
│   ├─ MapContainer                Panel  #E8EFF7
│   │   ├─ FloorMapImage           RawImage  ← assign floor plan texture
│   │   ├─ YouMarker               Panel  #1565C0  rounded  "You"
│   │   └─ UserLocationDot         Image  ← user_location_dot  24×24
│   ├─ PopularDestinationsCard_Top Panel  White  shadow
│   │   ├─ SectionTitle_Top        TMP  "Popular Destinations"  17px Bold
│   │   └─ ComputerLabRow_Top      Button [DestinationRow]
│   ├─ PopularDestinationsCard_Main Panel  White  shadow
│   │   ├─ SectionTitle_Main       TMP  "Popular Destinations"  17px Bold
│   │   ├─ ComputerLabRow          Button [DestinationRow]
│   │   ├─ CafeteriaRow            Button [DestinationRow]
│   │   └─ ExitRow                 Button [DestinationRow]
│   └─ StartARButton               Button  #1565C0  h=52  "Start AR Navigation"
│
└─ ARNavigationScreen  [ARNavigationScreenController, ScreenTransitionAnimator]
    ├─ ARTopBar                    Panel  dark semi-transparent  h=56
    │   ├─ BackButton              Button  "‹"  White
    │   ├─ SearchInputField        TMP_InputField
    │   └─ VoiceSearchButton       Button  "🎤"  White
    ├─ ARCameraFeed                RawImage  full-screen  ← AR RenderTexture
    ├─ ARArrowsOverlay             [ARArrowAnimator]
    │   ├─ FloorArrow_1            Image  ← ar_floor_arrow  alpha 1.0
    │   ├─ FloorArrow_2            Image  ← ar_floor_arrow  alpha 0.82
    │   ├─ FloorArrow_3            Image  ← ar_floor_arrow  alpha 0.64
    │   └─ FloorArrow_4            Image  ← ar_floor_arrow  alpha 0.46
    └─ BottomOverlay               VerticalLayoutGroup  h=160  bottom-anchored
        ├─ ControlButtonsRow       HorizontalLayoutGroup  h=48
        │   ├─ StopButton          Button  red pill  "⏹  Stop"
        │   ├─ RecenterButton      Button  blue pill  "↺  Recenter"
        │   └─ MapButton           Button  dark pill  "📍  Map"
        └─ DestinationCard         Button  White  rounded  h=80
            ├─ DirectionArrowImage Image  #1565C0  ← ar_floor_arrow  48×48
            ├─ LabelsGroup         VerticalLayoutGroup
            │   ├─ DestinationNameText  TMP  "Computer Lab"  20px Bold  #212121
            │   └─ DestinationMetaText  TMP  "15 meters · 30 sec"  14px  #757575
            └─ ChevronIcon         TMP  "›"  22px  #BDBDBD
```

---

## 🎨 DestinationRow Prefab

Each row is a **Button** with `DestinationRow.cs` attached.

```
DestinationRow (Button + DestinationRow.cs)  h=60
├─ IconBackground   Image  44×44  rounded  tinted colour
│   └─ IconImage    Image  ← icon sprite  28×28  White
├─ LabelsGroup      VerticalLayoutGroup  flex=1
│   ├─ DestinationNameText   TMP  16px SemiBold  #212121
│   └─ DestinationMetaText   TMP  13px Regular   #757575
├─ ChevronImage     TMP  "›"  20px  #BDBDBD
└─ RowDivider       Image  h=1  #E0E0E0
```

To save as a Prefab:
`Tools → Smart Indoor Nav → Save DestinationRow Prefab`

---

## 🎨 Colour Tokens

| Token              | Hex       | Usage                        |
|--------------------|-----------|------------------------------|
| Primary Blue       | #1565C0   | Buttons, icons, top bar      |
| Primary Blue Dark  | #0D47A1   | Gradient end, pressed states |
| Surface White      | #FFFFFF   | Cards, panels                |
| Background Grey    | #F5F5F5   | Floor bar, subtle bg         |
| Map Blue           | #E8EFF7   | Map container bg             |
| Text Primary       | #212121   | Headlines, row names         |
| Text Secondary     | #757575   | Meta text, subtitles         |
| Divider            | #E0E0E0   | Row separators               |
| Icon Computer Lab  | #1E88E5   | Computer Lab row icon        |
| Icon Room          | #FB8C00   | Room 305 row icon            |
| Icon Cafeteria     | #00897B   | Cafeteria row icon           |
| Icon Exit          | #43A047   | Exit row icon                |
| Stop Red           | #E53935   | Stop button pill             |

---

## 📐 RectTransform Rules

| Element                   | anchorMin     | anchorMax  | Notes                          |
|---------------------------|---------------|------------|--------------------------------|
| Screen roots              | (0,0)         | (1,1)      | Full stretch                   |
| TopSearchBar              | (0,1)         | (1,1)      | h=56, pivot top                |
| FloorBar                  | (0,1)         | (1,1)      | below search bar               |
| PopularDestinationsPanel  | (0,0)         | (1,0)      | h=310, pivot bottom            |
| StartARButton             | (0,0)         | (1,0)      | l/r 16pt, h=52, bottom 24pt   |
| BottomOverlay             | (0,0)         | (1,0)      | h=160, pivot bottom            |
| ARCameraFeed              | (0,0)         | (1,1)      | Full stretch behind overlay    |

---

## 🔤 Font Recommendation

Import **Plus Jakarta Sans** (free, Google Fonts) as a TMP FontAsset:
1. Download from fonts.google.com/specimen/Plus+Jakarta+Sans
2. `Assets → Create → TextMeshPro → Font Asset`
3. Set as default in `Project Settings → TextMeshPro`

---

## 🔌 AR Integration Notes

- `ARCameraFeed` RawImage → assign `Camera.targetTexture` from your
  AR Foundation `ARCameraBackground` camera.
- `ARArrowAnimator` handles the pulsing arrow animation automatically
  on play — no setup required.
- `ScreenTransitionAnimator` fades screens in/out — add a
  `CanvasGroup` component if it isn't already present (the builder
  adds it via `[RequireComponent]`).
- `RecenterButton.OnRecenterClicked()` → call `ARSession.Reset()`
  from your AR Foundation namespace.
