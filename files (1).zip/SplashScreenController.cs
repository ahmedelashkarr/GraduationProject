using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;

/// <summary>
/// SplashScreenController
/// Attach to the "SplashScreen" Panel GameObject.
/// </summary>
public class SplashScreenController : MonoBehaviour
{
    [Header("References")]
    public Button computerLabButton;
    public Button room305Button;
    public Button cafeteriaButton;
    public Button exitButton;

    [Header("Auto-transition (optional)")]
    public bool autoTransition = false;
    public float autoTransitionDelay = 2.5f;

    void Start()
    {
        computerLabButton?.onClick.AddListener(OnComputerLabClicked);
        room305Button?.onClick.AddListener(OnRoom305Clicked);
        cafeteriaButton?.onClick.AddListener(OnCafeteriaClicked);
        exitButton?.onClick.AddListener(OnExitClicked);

        if (autoTransition)
            StartCoroutine(AutoTransition());
    }

    IEnumerator AutoTransition()
    {
        yield return new WaitForSeconds(autoTransitionDelay);
        UIManager.Instance?.ShowMainScreen();
    }

    // ── Button handlers ──────────────────────────────────────────────────────

    public void OnComputerLabClicked()
    {
        Debug.Log("[Splash] Computer Lab tapped");
        NavigationManager.Instance?.SetDestination("Computer Lab");
        UIManager.Instance?.ShowMainScreen();
    }

    public void OnRoom305Clicked()
    {
        Debug.Log("[Splash] Room 305 tapped");
        NavigationManager.Instance?.SetDestination("Room 305");
        UIManager.Instance?.ShowMainScreen();
    }

    public void OnCafeteriaClicked()
    {
        Debug.Log("[Splash] Cafeteria tapped");
        NavigationManager.Instance?.SetDestination("Cafeteria");
        UIManager.Instance?.ShowMainScreen();
    }

    public void OnExitClicked()
    {
        Debug.Log("[Splash] Exit tapped");
        NavigationManager.Instance?.SetDestination("Exit");
        UIManager.Instance?.ShowMainScreen();
    }
}
