using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// UIManager — controls screen transitions between
/// SplashScreen, MainScreen, and ARNavigationScreen.
/// Attach to a persistent "UIManager" GameObject in the scene.
/// </summary>
public class UIManager : MonoBehaviour
{
    [Header("Screens")]
    public GameObject splashScreen;
    public GameObject mainScreen;
    public GameObject arNavigationScreen;

    private static UIManager _instance;
    public static UIManager Instance => _instance;

    void Awake()
    {
        if (_instance != null && _instance != this) { Destroy(gameObject); return; }
        _instance = this;
    }

    void Start()
    {
        ShowSplashScreen();
    }

    public void ShowSplashScreen()
    {
        SetActive(splashScreen, true);
        SetActive(mainScreen, false);
        SetActive(arNavigationScreen, false);
    }

    public void ShowMainScreen()
    {
        SetActive(splashScreen, false);
        SetActive(mainScreen, true);
        SetActive(arNavigationScreen, false);
    }

    public void ShowARNavigationScreen()
    {
        SetActive(splashScreen, false);
        SetActive(mainScreen, false);
        SetActive(arNavigationScreen, true);
    }

    private void SetActive(GameObject go, bool state)
    {
        if (go != null) go.SetActive(state);
    }
}
