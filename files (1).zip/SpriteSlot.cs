using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// SpriteSlot — marks a UI Image as needing an external sprite.
/// The SpriteAssigner on the screen root collects all slots and
/// lets you drag sprites from the Project window once, then apply.
///
/// Usage:
///   1. Add SpriteAssigner to SplashScreen / MainScreen / ARNavigationScreen.
///   2. Hit "Find All Slots" button in the custom Inspector (Editor/SpriteAssignerEditor.cs).
///   3. Drag your sprites from Project into each slot.
///   4. Hit "Apply Sprites".
/// </summary>
public class SpriteSlot : MonoBehaviour
{
    [Tooltip("Key matching a SpriteAssigner.SpriteBinding.key")]
    public string slotKey;
}
