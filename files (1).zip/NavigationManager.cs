using UnityEngine;

/// <summary>
/// NavigationManager — lightweight singleton that holds navigation state.
/// Attach to the persistent "UIManager" GameObject alongside UIManager.
/// </summary>
public class NavigationManager : MonoBehaviour
{
    public static NavigationManager Instance { get; private set; }

    public string CurrentDestination { get; private set; } = "Computer Lab";
    public int    DistanceMeters     { get; private set; } = 15;
    public int    ETASeconds         { get; private set; } = 30;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    public void SetDestination(string destination)
    {
        CurrentDestination = destination;
        Debug.Log($"[Nav] Destination set → {destination}");
        // TODO: query your pathfinding system for real distance / ETA
        // For now we keep defaults; replace with actual values:
        // DistanceMeters = pathfinder.GetDistance(destination);
        // ETASeconds     = pathfinder.GetETA(destination);
    }

    public void StopNavigation()
    {
        Debug.Log("[Nav] Navigation stopped");
        CurrentDestination = "";
    }
}
