using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.Events;

/// <summary>
/// DestinationRow — reusable prefab script for a single destination list row.
///
/// Prefab hierarchy:
///   DestinationRow (Button)
///   ├─ IconImage      (Image)
///   ├─ LabelsGroup    (Vertical Layout Group)
///   │   ├─ NameText   (TextMeshProUGUI)
///   │   └─ MetaText   (TextMeshProUGUI)  — "15 meters · 30 sec"
///   └─ ChevronImage   (Image)
/// </summary>
[RequireComponent(typeof(Button))]
public class DestinationRow : MonoBehaviour
{
    [Header("UI References")]
    public Image             iconImage;
    public TextMeshProUGUI   nameText;
    public TextMeshProUGUI   metaText;

    [Header("Data")]
    public string destinationName = "Computer Lab";
    public int    distanceMeters  = 15;
    public int    etaSeconds      = 30;
    public Sprite iconSprite;
    public Color  iconBackgroundColor = new Color(0.18f, 0.47f, 0.96f);

    [Header("Event")]
    public UnityEvent<string> onSelected;

    Button _btn;

    void Awake()
    {
        _btn = GetComponent<Button>();
        _btn.onClick.AddListener(OnClicked);
    }

    void Start()
    {
        Refresh();
    }

    public void Configure(string name, int dist, int eta, Sprite icon, Color bgColor)
    {
        destinationName        = name;
        distanceMeters         = dist;
        etaSeconds             = eta;
        iconSprite             = icon;
        iconBackgroundColor    = bgColor;
        Refresh();
    }

    void Refresh()
    {
        if (nameText != null) nameText.text = destinationName;
        if (metaText != null) metaText.text = $"{distanceMeters} meters · {etaSeconds} sec";
        if (iconImage != null)
        {
            iconImage.sprite = iconSprite;
            iconImage.color  = iconBackgroundColor;
        }
    }

    void OnClicked()
    {
        Debug.Log($"[DestinationRow] Selected: {destinationName}");
        NavigationManager.Instance?.SetDestination(destinationName);
        onSelected?.Invoke(destinationName);
    }
}
