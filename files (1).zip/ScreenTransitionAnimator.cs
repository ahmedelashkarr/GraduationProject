using UnityEngine;
using UnityEngine.UI;
using System.Collections;

/// <summary>
/// ScreenTransitionAnimator
/// Attach to each screen root Panel.
/// UIManager calls FadeIn() / FadeOut() instead of SetActive directly
/// when you wire it through this component.
///
/// Usage: Replace UIManager.SetActive calls with:
///   FindObjectOfType<ScreenTransitionAnimator>().FadeIn(screen);
/// </summary>
[RequireComponent(typeof(CanvasGroup))]
public class ScreenTransitionAnimator : MonoBehaviour
{
    [Header("Timing")]
    public float fadeDuration = 0.22f;

    CanvasGroup _cg;

    void Awake() => _cg = GetComponent<CanvasGroup>();

    public void FadeIn(System.Action onComplete = null)
    {
        gameObject.SetActive(true);
        StopAllCoroutines();
        StartCoroutine(FadeRoutine(0, 1, onComplete));
    }

    public void FadeOut(System.Action onComplete = null)
    {
        StopAllCoroutines();
        StartCoroutine(FadeRoutine(1, 0, () =>
        {
            gameObject.SetActive(false);
            onComplete?.Invoke();
        }));
    }

    IEnumerator FadeRoutine(float from, float to, System.Action onComplete)
    {
        float elapsed = 0;
        _cg.alpha = from;
        while (elapsed < fadeDuration)
        {
            elapsed += Time.unscaledDeltaTime;
            _cg.alpha = Mathf.Lerp(from, to, elapsed / fadeDuration);
            yield return null;
        }
        _cg.alpha = to;
        onComplete?.Invoke();
    }
}
