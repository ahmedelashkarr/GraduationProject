using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

/// <summary>
/// SpriteAssigner — attach to the Canvas root or any screen root.
/// Pairs sprite keys with actual Sprite assets, then pushes them
/// to every matching SpriteSlot child in one click.
///
/// Import your SVG/PNG sprites into Assets/Sprites/ first,
/// then assign them here.
/// </summary>
public class SpriteAssigner : MonoBehaviour
{
    [System.Serializable]
    public class SpriteBinding
    {
        public string key;
        public Sprite sprite;
    }

    [Header("Sprite Bindings")]
    [Tooltip("Add one entry per sprite key used across all SpriteSlot components.")]
    public List<SpriteBinding> bindings = new List<SpriteBinding>
    {
        new SpriteBinding { key = "ar_pin_icon"       },
        new SpriteBinding { key = "ar_floor_arrow"    },
        new SpriteBinding { key = "icon_computer"     },
        new SpriteBinding { key = "icon_room"         },
        new SpriteBinding { key = "icon_cafeteria"    },
        new SpriteBinding { key = "icon_exit"         },
        new SpriteBinding { key = "stop_button_icon"  },
        new SpriteBinding { key = "success_check"     },
        new SpriteBinding { key = "user_location_dot" },
    };

    /// <summary>Called by the custom Editor button and at runtime start.</summary>
    public void ApplySprites()
    {
        // Build lookup
        var map = new Dictionary<string, Sprite>();
        foreach (var b in bindings)
            if (!string.IsNullOrEmpty(b.key) && b.sprite != null)
                map[b.key] = b.sprite;

        // Walk all SpriteSlot descendants
        var slots = GetComponentsInChildren<SpriteSlot>(includeInactive: true);
        int applied = 0;
        foreach (var slot in slots)
        {
            if (map.TryGetValue(slot.slotKey, out Sprite sp))
            {
                var img = slot.GetComponent<Image>();
                if (img != null) { img.sprite = sp; applied++; }
            }
        }
        Debug.Log($"[SpriteAssigner] Applied {applied} / {slots.Length} sprites.");
    }

#if UNITY_EDITOR
    void Reset() { } // show component in Inspector on attach
#endif
}
