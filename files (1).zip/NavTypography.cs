// NavTypography.cs
// Static constants for every text style used in the app.
// Import "Plus Jakarta Sans" (free, Google Fonts) as a TMP FontAsset
// and assign it to TMP_Settings > Default Font Asset for best results.

using UnityEngine;
using TMPro;

public static class NavTypography
{
    // ── Font sizes ────────────────────────────────────────────────────────────
    public const float SIZE_H1_BADGE      = 28f;   // "AR" badge
    public const float SIZE_H1_TITLE      = 22f;   // "Smart Indoor Navigation"
    public const float SIZE_SECTION_TITLE = 17f;   // "Popular Destinations"
    public const float SIZE_CTA           = 17f;   // "Start AR Navigation"
    public const float SIZE_ROW_NAME      = 16f;   // destination name
    public const float SIZE_ROW_META      = 13f;   // "15 meters · 30 sec"
    public const float SIZE_PILL_LABEL    = 14f;   // "Stop", "Recenter", "Map"
    public const float SIZE_CARD_TITLE    = 20f;   // AR dest card name
    public const float SIZE_CARD_META     = 14f;   // AR dest card meta
    public const float SIZE_FLOOR_LABEL   = 17f;   // "Floor 2"
    public const float SIZE_SEARCH        = 14f;   // search placeholder

    // ── Colours ───────────────────────────────────────────────────────────────
    public static Color TextPrimary   => Hex("#212121");
    public static Color TextSecondary => Hex("#757575");
    public static Color TextOnBlue    => Color.white;
    public static Color TextChevron   => Hex("#BDBDBD");

    static Color Hex(string h) {
        ColorUtility.TryParseHtmlString(h, out Color c); return c;
    }

    /// <summary>Apply standard nav style to a TMP component.</summary>
    public static void Apply(TextMeshProUGUI tmp, float size,
        FontStyles style, Color color)
    {
        tmp.fontSize   = size;
        tmp.fontStyle  = style;
        tmp.color      = color;
        tmp.raycastTarget = false;
    }
}
