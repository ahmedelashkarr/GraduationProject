using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// ARArrowAnimator
/// Attach to the "ARArrowsOverlay" GameObject.
/// Pulses the opacity of each child arrow sequentially to simulate
/// animated floor navigation arrows.
/// </summary>
public class ARArrowAnimator : MonoBehaviour
{
    [Header("Settings")]
    public float cycleSpeed  = 1.2f;   // full cycle per second
    public float minAlpha    = 0.15f;
    public float maxAlpha    = 1.0f;
    public float phaseOffset = 0.25f;  // stagger between arrows (0–1)

    Image[] _arrows;

    void Awake()
    {
        _arrows = GetComponentsInChildren<Image>(includeInactive: false);
    }

    void Update()
    {
        float t = Time.time * cycleSpeed;
        for (int i = 0; i < _arrows.Length; i++)
        {
            // Each arrow offset in phase
            float phase   = t - i * phaseOffset;
            float alpha   = Mathf.Lerp(minAlpha, maxAlpha,
                                (Mathf.Sin(phase * Mathf.PI * 2f) + 1f) * 0.5f);
            Color c       = _arrows[i].color;
            c.a           = alpha;
            _arrows[i].color = c;
        }
    }
}
