using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// ARNavigationScreenController
/// Attach to the "ARNavigationScreen" Panel GameObject.
/// </summary>
public class ARNavigationScreenController : MonoBehaviour
{
    [Header("Top Bar")]
    public Button backButton;
    public TMP_InputField searchInputField;
    public Button voiceSearchButton;

    [Header("AR Viewport")]
    public RawImage arCameraFeed;              // bind to AR camera RenderTexture

    [Header("Bottom Controls")]
    public Button stopButton;
    public Button recenterButton;
    public Button mapButton;

    [Header("Destination Card")]
    public TextMeshProUGUI destinationNameText;
    public TextMeshProUGUI destinationDistanceText;
    public Button destinationCardChevronButton;

    void Start()
    {
        backButton?.onClick.AddListener(OnBackClicked);
        voiceSearchButton?.onClick.AddListener(OnVoiceSearchClicked);

        stopButton?.onClick.AddListener(OnStopClicked);
        recenterButton?.onClick.AddListener(OnRecenterClicked);
        mapButton?.onClick.AddListener(OnMapClicked);

        destinationCardChevronButton?.onClick.AddListener(OnDestinationCardClicked);

        if (searchInputField != null)
            searchInputField.onEndEdit.AddListener(OnSearchSubmitted);
    }

    void OnEnable()
    {
        RefreshDestinationCard();
    }

    void RefreshDestinationCard()
    {
        var nm = NavigationManager.Instance;
        if (nm == null) return;

        if (destinationNameText != null)
            destinationNameText.text = nm.CurrentDestination;
        if (destinationDistanceText != null)
            destinationDistanceText.text = $"{nm.DistanceMeters} meters · {nm.ETASeconds} sec";
    }

    // ── Top bar ───────────────────────────────────────────────────────────────

    public void OnBackClicked()
    {
        Debug.Log("[AR] Back tapped — returning to Main");
        UIManager.Instance?.ShowMainScreen();
    }

    public void OnVoiceSearchClicked()
    {
        Debug.Log("[AR] Voice search tapped");
    }

    public void OnSearchSubmitted(string query)
    {
        Debug.Log($"[AR] Search: {query}");
        NavigationManager.Instance?.SetDestination(query);
        RefreshDestinationCard();
    }

    // ── Control buttons ───────────────────────────────────────────────────────

    public void OnStopClicked()
    {
        Debug.Log("[AR] Stop navigation");
        NavigationManager.Instance?.StopNavigation();
        UIManager.Instance?.ShowMainScreen();
    }

    public void OnRecenterClicked()
    {
        Debug.Log("[AR] Recenter camera");
        // Hook into your AR session recenter call here, e.g.:
        // ARSession.Reset();
    }

    public void OnMapClicked()
    {
        Debug.Log("[AR] Switch to map view");
        UIManager.Instance?.ShowMainScreen();
    }

    // ── Destination card ──────────────────────────────────────────────────────

    public void OnDestinationCardClicked()
    {
        Debug.Log("[AR] Destination card expanded");
        // Show expanded info panel if needed
    }
}
